# Brain Tumor Detection from MRI Images

This project detects and segments brain tumors from MRI scans using both classical computer vision techniques (K-means) and deep learning (CNN). It includes a modular architecture, visualization tools, and an optional GUI.

---

## 🧪 Dataset

Use the [Brain MRI Images for Brain Tumor Detection](https://www.kaggle.com/navoneel/brain-mri-images-for-brain-tumor-detection)  dataset from Kaggle.

Folder structure: