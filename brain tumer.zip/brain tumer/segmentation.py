import cv2
import numpy as np
from utils import load_and_preprocess

def segment_tumor_kmeans(image_path, output_path):
    """Segment tumor region using K-means clustering."""
    img = load_and_preprocess(image_path)  # Ensure this function exists in utils.py

    Z = img.reshape((-1, 1)).astype(np.float32)
    
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.85)
    K = 2
    _, labels, centers = cv2.kmeans(Z, K, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

    segmented = centers[labels.flatten()].reshape(img.shape).astype(np.uint8)

    # Threshold and clean up
    _, binary = cv2.threshold(segmented, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))

    result = cv2.bitwise_and(img, img, mask=binary)
    cv2.imwrite(output_path, result)
    return result